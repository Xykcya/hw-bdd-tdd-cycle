describe MoviesController do
  
  describe 'show' do

  end

end